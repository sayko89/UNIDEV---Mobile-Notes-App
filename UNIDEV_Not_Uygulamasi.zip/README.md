
# UNIDEV Not Uygulaması

Bu proje, Flutter ile geliştirilmiş bir mobil not alma uygulamasıdır. Notlar başlık, içerik ve kategori bilgisiyle birlikte yerel olarak saklanır. Veri kalıcılığı için Hive veritabanı kullanılmıştır.

## Özellikler
- Yeni not ekleme
- Not düzenleme ve silme
- Kategori seçimi
- Yerel veri saklama

## Başlangıç
```bash
flutter pub get
flutter packages pub run build_runner build
flutter run
```

## Geliştirici: Yazılım Mühendisi Ekip (UNIDEV)
